Formalization of the space of complex bounded operators

Author: Jose Manuel Rodriguez Caballero, Dominique Unruh
Licence: BSD 3-clause
